package com.javahelps.onlinedoctor;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.util.HashMap;

import static android.content.ContentValues.TAG;


public class Register extends AppCompatActivity {
    EditText name,phone,email, pass, regid,dob,gender,conpass;
    Button regg;
     ProgressBar progressBar;
TextView lg;
    private FirebaseAuth mAuth;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Create Account");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        name=findViewById(R.id.nameET);
        email = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        regg = findViewById(R.id.reg);
        progressBar = findViewById(R.id.progressBar2);
        regid = findViewById(R.id.reg_id);
        lg= findViewById(R.id.crt1);
        dob=findViewById(R.id.dob);
        gender=findViewById(R.id.gender);
        phone=findViewById(R.id.phd);
        conpass=findViewById(R.id.conpass);
        mAuth = FirebaseAuth.getInstance();
        
        lg.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),loginActivity2.class));
                finish();
            }
        });

        regg.setOnClickListener(v -> {
            String Email = email.getText().toString().trim();
            String password = pass.getText().toString().trim();
            String nmd=name.getText().toString().trim();
            String phd=phone.getText().toString().trim();
            String Gender=gender.getText().toString().trim();
            String Con_pass=conpass.getText().toString().trim();
            final int rid = Integer.parseInt(regid.getText().toString());
            if(TextUtils.isEmpty(nmd)){
                name.setError("Name is must");
                name.setFocusable(true);
            }else if(TextUtils.isEmpty(phd)){
                phone.setError("There must be a phone number");
                phone.setFocusable(true);
            } else if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
                email.setError("Invalid Email");
                email.setFocusable(true);
            } else if (password.length() < 6) {
                pass.setError("Password must be greater than 6 character");
                pass.setFocusable(true);
            }else if(!Gender.equals("Male") && !Gender.equals("Female") && !Gender.equals("Others")){
                gender.setError("Write according to the hint");
                gender.setFocusable(true);
            }
            else if (rid < 10000 || rid > 99999) {
                regid.setError("Invalid Registration ID");
                regid.setFocusable(true);
            }else if(TextUtils.isEmpty(Integer.toString(rid))){
                regid.setError("Please provide your Registration ID");
                regid.setFocusable(true);
            }
            else if(!password.equals(Con_pass)){
                conpass.setError("Password does not matched");
                conpass.setFocusable(true);
            }
            else {
                registerUser(Email, password);
            }
        });
    }

    private void registerUser(String email, String password) {
        progressBar.setVisibility(View.VISIBLE);


        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = mAuth.getCurrentUser();
                //String eml = user.getEmail();
                //String uid=user.getUid();
                //String nm=user.getDisplayName();
                //String ph=user.getPhoneNumber();
                //String rd=user.getTenantId();
                String eml = user.getEmail();
                String uid=user.getUid();
                String nm="Doctor, "+name.getEditableText().toString();
                String ph=phone.getEditableText().toString();
                String Dob=dob.getEditableText().toString();
                String Gender=gender.getEditableText().toString();
                String rd=regid.getEditableText().toString();

                HashMap<Object, String > hashMap=new HashMap<>();
                hashMap.put("email",eml);
                hashMap.put("uid",uid);
                hashMap.put("name",nm);
                hashMap.put("OnlineStatus","online");
                hashMap.put("TypingTo","noOne");
                hashMap.put("phone",ph);
                hashMap.put("image","");
                hashMap.put("cover","");
                hashMap.put("RegId",rd);
                hashMap.put("gender",Gender);
                hashMap.put("dob",Dob);

                FirebaseDatabase database=FirebaseDatabase.getInstance();
                DatabaseReference reference=database.getReference("Users");
                reference.child(uid).setValue(hashMap);



                //Toast.makeText(Register.this,"Registered...\n"+ user.getEmail(),Toast.LENGTH_SHORT).show();
           startActivity(new Intent(Register.this, verification.class));
           //finish();
            } else {
                Toast.makeText(Register.this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.INVISIBLE);
                finish();
            }

        }).addOnFailureListener(e -> Toast.makeText(Register.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}
