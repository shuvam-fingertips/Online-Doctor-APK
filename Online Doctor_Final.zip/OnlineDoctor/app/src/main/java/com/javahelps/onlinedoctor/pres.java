package com.javahelps.onlinedoctor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class pres extends AppCompatActivity {
    Button btn1, btn2;
    EditText et1, et2;
    String st;
    String st1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pres);



        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        btn2 = findViewById(R.id.btn2);
        btn1 = findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(pres.this,pres_2.class);
                st = et1.getText().toString();
                st1 = et2.getText().toString();
                i.putExtra("value", st);
                i.putExtra("age", st1);
                startActivity(i);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(pres.this, exp.class);
                st = et1.getText().toString();
                st1 = et2.getText().toString();
                i.putExtra("value", st);
                i.putExtra("age", st1);
                startActivity(i);
            }
        });

    }
}