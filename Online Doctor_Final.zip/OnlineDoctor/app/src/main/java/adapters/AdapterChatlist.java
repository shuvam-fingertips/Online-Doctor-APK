package adapters;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.core.OnlineState;
import com.javahelps.onlinedoctor.R;
import com.javahelps.onlinedoctor.chat;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

import models.ModelUsers;

public class AdapterChatlist extends RecyclerView.Adapter<AdapterChatlist.MyHolder>{
    Context context;
    List<ModelUsers> usersList;
    private HashMap<String, String> lastMessageMap;

    public AdapterChatlist(Context context, List<ModelUsers> usersList) {
        this.context = context;
        this.usersList = usersList;
        lastMessageMap = new HashMap<>();
    }

    @NonNull

    @Override
    public MyHolder onCreateViewHolder(@NonNull  ViewGroup viewGroup, int i) {

        View view= LayoutInflater.from(context).inflate(R.layout.row_chatlist,viewGroup,false);
        return new MyHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull  AdapterChatlist.MyHolder myHolder, int i) {

        String hisUid=usersList.get(i).getUid();
        String userImage=usersList.get(i).getImage();
        String username=usersList.get(i).getName();
        String lastMsg=lastMessageMap.get(hisUid);
        //String onlineStatus =List.get(i).getOnlineStatus();

        myHolder.nameTv.setText(username);
        if(lastMsg==null || lastMsg.equals("default")){
            myHolder.lastMessageTv.setVisibility(View.GONE);
        }
        else{
            myHolder.lastMessageTv.setVisibility(View.VISIBLE);
            myHolder.lastMessageTv.setText(lastMsg);
        }
try {
    Picasso.get().load(userImage).placeholder(R.drawable.ic_default_face).into(myHolder.profileTv);
}
catch (Exception e){
    Picasso.get().load(R.drawable.ic_default_face).into(myHolder.profileTv);
}
//if(usersList.get(i).getOnlineStatus().equals("online")){
  // myHolder.onlineStatusTv.setImageResource(R.drawable.click_online);

//}else{
  //  myHolder.onlineStatusTv.setImageResource(R.drawable.click_offline);

//}
myHolder.itemView.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent=new Intent(context, chat.class);
        intent.putExtra("hisUid",hisUid);
        context.startActivity(intent);

    }
});

    }
    public void setLastMessageMap(String userid,String lstMsg){
        lastMessageMap.put(userid,lstMsg);
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }

    class  MyHolder extends RecyclerView.ViewHolder{

        ImageView profileTv,onlineStatusTv;
        TextView nameTv,lastMessageTv;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            profileTv=itemView.findViewById(R.id.profileTv);
            onlineStatusTv=itemView.findViewById(R.id.onlineStatus);
            nameTv=itemView.findViewById(R.id.naam);
            lastMessageTv=itemView.findViewById(R.id.lastMsg);
        }
    }
}
