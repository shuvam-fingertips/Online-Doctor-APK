package com.javahelps.onlinedoctor;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Register_p extends AppCompatActivity {
    EditText name,phone,email, pass, regid,gender,conpass;
    Button reg_p;
    ProgressBar progressBar;
    TextView lg;
    private FirebaseAuth mAuth;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_p);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Create Account");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        name=findViewById(R.id.nameet);
        phone=findViewById(R.id.pn);
        email = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        conpass=findViewById(R.id.conpass);
reg_p=findViewById(R.id.reg);
        progressBar = findViewById(R.id.progressBar2);
        gender=findViewById(R.id.gender);

        lg= findViewById(R.id.crt1);
        mAuth = FirebaseAuth.getInstance();

        lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),login_p.class));
                finish();
            }
        });

        reg_p.setOnClickListener(v -> {
            String Email = email.getText().toString().trim();
            String password = pass.getText().toString().trim();
            String nmm = name.getText().toString().trim();
            String phh = phone.getText().toString().trim();
            String Gender=gender.getText().toString().trim();
            String Con_pass=conpass.getText().toString().trim();
            if(TextUtils.isEmpty(nmm)){
                name.setError("Name is must");
                name.setFocusable(true);
            }else if(TextUtils.isEmpty(phh)){
                phone.setError("There must be a valid phone number");
                phone.setFocusable(true);
            }
            else if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
                email.setError("Invalid Email");
                email.setFocusable(true);
            } else if (password.length() < 6) {
                pass.setError("Password must be greater than 6 character");
                pass.setFocusable(true);
            }else  if(!password.equals(Con_pass)){
                conpass.setError("Password  does not matched");
                conpass.setFocusable(true);
            }else if(TextUtils.isEmpty(Gender)){
                gender.setError("Gender must not be empty");
                gender.setFocusable(true);
            }else if(!Gender.equals("Male") && !Gender.equals("Female") && !Gender.equals("Others")){
                gender.setError("Write according to the hint");
                gender.setFocusable(true);
            }
            else {
                registerUser(Email, password);
            }
        });
    }

    private void registerUser(String email, String password) {
        progressBar.setVisibility(View.VISIBLE);


        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = mAuth.getCurrentUser();
                String eml = user.getEmail();
                String uid=user.getUid();
                String nm=name.getEditableText().toString();
                String ph=phone.getEditableText().toString();
                String Gender=gender.getEditableText().toString();

                HashMap<Object, String > hashMap=new HashMap<>();
                hashMap.put("email",eml);
                hashMap.put("uid",uid);
                hashMap.put("name",nm);
                hashMap.put("OnlineStatus","online");
                hashMap.put("TypingTo","noOne");
                hashMap.put("phone",ph);
                hashMap.put("image","");
                hashMap.put("cover","");
                hashMap.put("gender",Gender);

                FirebaseDatabase database=FirebaseDatabase.getInstance();
                DatabaseReference reference=database.getReference("Users");
                reference.child(uid).setValue(hashMap);



                //Toast.makeText(Register.this,"Registered...\n"+ user.getEmail(),Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Register_p.this, verification_p.class));
                //finish();
            } else {
                Toast.makeText(Register_p.this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.INVISIBLE);
                finish();
            }

        }).addOnFailureListener(e -> Toast.makeText(Register_p.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
    }
