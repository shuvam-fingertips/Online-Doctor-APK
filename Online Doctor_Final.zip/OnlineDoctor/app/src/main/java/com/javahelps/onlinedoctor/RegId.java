package com.javahelps.onlinedoctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class RegId extends AppCompatActivity {
    EditText regIdET;
    Button lg_Button,s_btn;
    FirebaseUser user;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    FirebaseAuth firebaseAuth;
    String registrationID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_id);
        regIdET=(EditText)findViewById(R.id.regIdET);
        lg_Button=findViewById(R.id.lg_button);
        s_btn=findViewById(R.id.s_btn);


        firebaseAuth= FirebaseAuth.getInstance();
        user=firebaseAuth.getCurrentUser();
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("Users");


        Query query=databaseReference.orderByChild("email").equalTo(user.getEmail());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull  DataSnapshot dataSnapshot) {
               // String rd=regIdET.getEditableText().toString();
                for(DataSnapshot ds:dataSnapshot.getChildren()) {
                   registrationID = "" + ds.child("RegId").getValue();
                 //registrationID="10125";


                    //regIdET.setText(rd);
                    //t3.setText(rd);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        s_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s_btn.isHovered();
                String rd=regIdET.getText().toString().trim();
                //regIdET.setText(rd);
                //t2.setText(rd);

                if(registrationID.equals(rd)){
                    lg_Button.setVisibility(View.VISIBLE);
                    Toast.makeText(RegId.this,"Please Click Sign IN to Continue",Toast.LENGTH_LONG).show();
                }
                else{
                    regIdET.setError("INVALID");
                    regIdET.setFocusable(true);
                    Toast.makeText(RegId.this,"Sorry!Registration ID is not matched",Toast.LENGTH_SHORT).show();
                }
            }
        });
        lg_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lg_Button.isHovered();
                if (!user.isEmailVerified()) {
                    startActivity(new Intent(getApplicationContext(), verification.class));
                    finish();
                } else {

                        //DocumentReference documentReference = fStore.collection("users").document(userId);
                        //documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
                        //           @Override
                        //  public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                        Toast.makeText(RegId.this, "Logged In\n" + user.getEmail(), Toast.LENGTH_SHORT).show();
                        //startActivity(new Intent(loginActivity2.this, dashboardfactivity.class));

                        startActivity(new Intent(getApplicationContext(), dashboard_p.class));
                        finish();
                    }
                }
            });
        }
    }
