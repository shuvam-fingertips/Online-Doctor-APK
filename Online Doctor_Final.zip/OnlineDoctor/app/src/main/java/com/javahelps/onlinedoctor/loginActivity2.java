package com.javahelps.onlinedoctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class loginActivity2<AuthResult> extends AppCompatActivity {

    EditText emm,pss;
    TextView fp,new_sign;
    Button loginn;
    ProgressBar pb;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Login");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        mAuth = FirebaseAuth.getInstance();

        emm=findViewById(R.id.em);
        pss=findViewById(R.id.pass);
        fp=findViewById(R.id.forgotpass);
        loginn=findViewById(R.id.lgg);
pb=findViewById(R.id.progressBar);
new_sign=findViewById(R.id.new_sign);
        fp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText resetMail=new EditText(v.getContext());
                AlertDialog.Builder password=new AlertDialog.Builder(v.getContext());
                password.setTitle("Want To Reset password?");
                password.setMessage("Enter Your Registered Email");
                password.setView(resetMail);

                password.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String mail=resetMail.getText().toString();
                        mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(loginActivity2.this,"Resent Link has sent to your email ",Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(loginActivity2.this, "Sorry!!!Sending Link failed "+e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                password.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                password.create().show();
            }
        });
        loginn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=emm.getText().toString().trim();
                String ps=pss.getText().toString().trim();
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    emm.setError("Invalid Email");
                    emm.setFocusable(true);

                }
                else{
                    loginUser(email,ps);
                }
            }
        });
        new_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Register.class));
            }
        });

    }

    private void loginUser(String email, String password) {



        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
            pb.setVisibility(View.VISIBLE);
            if (task.isSuccessful()) {

                FirebaseUser user = mAuth.getCurrentUser();
                if (!user.isEmailVerified()) {
                    startActivity(new Intent(getApplicationContext(), RegId.class));
                    finish();
                } else {
                    if (task.getResult().getAdditionalUserInfo().isNewUser()) {
                        String eml = user.getEmail();
                        String uid = user.getUid();
                        String nm = user.getDisplayName();
                        String ph = user.getPhoneNumber();

                        HashMap<Object, String> hashMap = new HashMap<>();
                        hashMap.put("email", eml);
                        hashMap.put("uid", uid);
                        hashMap.put("name", "");
                        hashMap.put("OnlineStatus","online");
                        hashMap.put("TypingTo","noOne");
                        hashMap.put("phone", "");
                        hashMap.put("image", "");
                        hashMap.put("cover", "");

                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference reference = database.getReference("Users");
                        reference.child(uid).setValue(hashMap);
                        //DocumentReference documentReference = fStore.collection("users").document(userId);
                        //documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
                        //           @Override
                        //  public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                        Toast.makeText(loginActivity2.this, "Logged In\n" + user.getEmail(), Toast.LENGTH_SHORT).show();
                        //startActivity(new Intent(loginActivity2.this, dashboardfactivity.class));

                        startActivity(new Intent(getApplicationContext(), RegId.class));
                        finish();
                    } else {
                        //Toast.makeText(loginActivity2.this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                        Toast.makeText(loginActivity2.this, "Logged In\n" + user.getEmail(), Toast.LENGTH_SHORT).show();
                        //startActivity(new Intent(loginActivity2.this, dashboardfactivity.class));

                        startActivity(new Intent(getApplicationContext(), RegId.class));
                        finish();

                    }
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure( Exception e) {
                Toast.makeText(loginActivity2.this, "Authentication Failed!! " + e.getMessage(), Toast.LENGTH_SHORT).show();
                pb.setVisibility(View.INVISIBLE);
            }
        });
    }




    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

}
