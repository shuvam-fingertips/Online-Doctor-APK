package com.javahelps.onlinedoctor;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import adapters.AdapterChatlist;
import models.ModelChat;
import models.ModelChatList;
import models.ModelUsers;

public class ChatFragment extends Fragment {

    FirebaseAuth firebaseAuth;
    RecyclerView recyclerView;
    List<ModelChatList> chatLists;
    List<ModelUsers> usersList;
    DatabaseReference reference;
    FirebaseUser currentuser;
    AdapterChatlist adapterChatlist;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_chat,container,false);
        firebaseAuth=FirebaseAuth.getInstance();
        currentuser=FirebaseAuth.getInstance().getCurrentUser();

        recyclerView=view.findViewById(R.id.recylerView);

        chatLists=new ArrayList<>();
        reference= FirebaseDatabase.getInstance().getReference("ChatList").child(currentuser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chatLists.clear();
                for (DataSnapshot ds: dataSnapshot.getChildren()){
                    ModelChatList chatList=ds.getValue(ModelChatList.class);
                    chatLists.add(chatList);
                }
                loadChats();
            }

            @Override
            public void onCancelled(@NonNull  DatabaseError error) {

            }
        });

        return view;
    }

    private void loadChats() {
        usersList=new ArrayList<>();
        reference=FirebaseDatabase.getInstance().getReference("Users");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                usersList.clear();
                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    ModelUsers user=ds.getValue(ModelUsers.class);
                    for(ModelChatList chatList:chatLists){
                        if(user.getUid()!=null && user.getUid().equals(chatList.getId())){
                            usersList.add(user);
                            break;
                        }
                    }

                    String onlineStatus = "" + ds.child("OnlineStatus").getValue();
                    if(onlineStatus.equals("online")){

                    }

                    adapterChatlist=new AdapterChatlist(getContext(),usersList);
                    recyclerView.setAdapter(adapterChatlist);
                    for(int i=0;i<usersList.size();i++){
                        lastMessage(usersList.get(i).getUid());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void lastMessage(String userid) {
    DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Chats");
    reference.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            String thelastmsg="default";
            for(DataSnapshot ds:dataSnapshot.getChildren()){
                ModelChat chat=ds.getValue(ModelChat.class);
                if(chat==null){
                    continue;
                }
                String sender=chat.getSender();
                String receiver=chat.getReceiver();
                if(sender==null || receiver==null){
                    continue;
                }
                if(chat.getReceiver().equals(currentuser.getUid()) && chat.getSender().equals(userid) || chat.getReceiver().equals(userid) && chat.getSender().equals(currentuser.getUid())){
                   if(chat.getType().equals("image")){
                        thelastmsg="Sent you a photo";
                    }
                    else {
                       thelastmsg = chat.getMessage();
                    }
                }
            }
            adapterChatlist.setLastMessageMap(userid,thelastmsg);
            adapterChatlist.notifyDataSetChanged();

        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    });
    }
}