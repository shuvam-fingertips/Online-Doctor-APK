package com.javahelps.onlinedoctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class TheirProfile extends AppCompatActivity {


    String uid;
    FirebaseAuth firebaseAuth;
DatabaseReference databaseReference;
    ImageView avatar,cover;
    TextView namee,emaill,phonee,spc,exp,dobb,gen,fee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_their_profile);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Doctor's Details");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);


        avatar=findViewById(R.id.avatar);
        namee=findViewById(R.id.name);
        emaill=findViewById(R.id.email);
        phonee=findViewById(R.id.phone);
        spc=findViewById(R.id.spcl);
        exp=findViewById(R.id.exp);
        dobb=findViewById(R.id.dob);
        gen=findViewById(R.id.gen);
        fee=findViewById(R.id.fees);

        cover=findViewById(R.id.cover);

        firebaseAuth=firebaseAuth.getInstance();
        Intent intent=getIntent();
        uid=intent.getStringExtra("uid");
        //checkUserStatus();
        databaseReference= FirebaseDatabase.getInstance().getReference("Users");

        Query query=databaseReference.orderByChild("uid").equalTo(uid);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot ds:dataSnapshot.getChildren()){
                    String name=""+ds.child("name").getValue();
                    String email=""+ds.child("email").getValue();
                    String phone=""+ds.child("phone").getValue();
                    String special=""+ds.child("special").getValue();
                    String experience=""+ds.child("experience").getValue();
                    String dob=""+ds.child("dob").getValue();
                    String gender=""+ds.child("gender").getValue();
                    String fees=""+ds.child("fees").getValue();
                    String image=""+ds.child("image").getValue();
                    String coverp=""+ds.child("cover").getValue();

                    namee.setText(name);
                    emaill.setText(email);
                    phonee.setText(phone);
                    spc.setText(special);
                    exp.setText(experience);
                    dobb.setText(dob);
                    gen.setText(gender);
                    fee.setText(fees);
                    try{
                        Picasso.get().load(image).into(avatar);
                    }
                    catch (Exception e){
                        Picasso.get().load(R.drawable.ic_default_face).into(avatar);
                    }

                    try{
                        Picasso.get().load(coverp).into(cover);
                    }
                    catch (Exception e){

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //loadHisProfile();

    }

   // private void loadHisProfile() {
       // LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        //linearLayoutManager.setStackFromEnd(true);
        //linearLayoutManager.setReverseLayout(true);


    //}

    private void checkUserStatus(){
        FirebaseUser user=firebaseAuth.getCurrentUser();
        if(user!=null){

        }else{
            startActivity(new Intent(TheirProfile.this,Conas.class));
            finish();
        }

    }
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}