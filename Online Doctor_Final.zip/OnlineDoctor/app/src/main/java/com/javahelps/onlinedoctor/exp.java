package com.javahelps.onlinedoctor;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class exp extends AppCompatActivity {
    DatabaseHelper myDb;
    TextView tv1;
    EditText editName,editSurname,editMarks,editId;
    Button btnAddData,btnviewAll,btndelete,btnUpdate,btnout;
    ImageButton btnmail;
    ImageView iv1,iv2,iv3;
    String a,b;
    String c,d,e;
    private int requestCode;
    private int resultCode;
    @Nullable
    private Intent data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exp);
        myDb=new DatabaseHelper(this);
        a=getIntent().getStringExtra("value");
        b=getIntent().getStringExtra("age");

        editName=findViewById(R.id.editText_name);
        editSurname=findViewById(R.id.editText_surname);
        tv1=findViewById(R.id.tv1);
        editMarks=findViewById(R.id.editText_Marks);
        btnAddData=(Button) findViewById(R.id.button_add);
        btnviewAll=(Button) findViewById(R.id.button_viewAll);
        btnUpdate=(Button) findViewById(R.id.button_update);
        btndelete=(Button) findViewById(R.id.button_delete);
        btnmail=(ImageButton) findViewById(R.id.btnmail);
        btnout=findViewById(R.id.button_out);
        editId=findViewById(R.id.editTextId);
        iv1=findViewById(R.id.iv1);
        iv2=findViewById(R.id.iv2);
        iv3=findViewById(R.id.iv3);
        AddData();
        viewAll();
        UpdateData();
        DeleteData();
    }
    public void getSpeechInput(View view){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        if(i.resolveActivity(getPackageManager()) != null){
            startActivityForResult(i, 10);
        }else{
            Toast.makeText(this,"Not Supported",Toast.LENGTH_SHORT).show();}
    }
    public void getSpeech(View view){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        if(i.resolveActivity(getPackageManager()) != null){
            startActivityForResult(i, 11);
        }else{
            Toast.makeText(this,"Not Supported",Toast.LENGTH_SHORT).show();}
    }
    public void get(View view){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        if(i.resolveActivity(getPackageManager()) != null){
            startActivityForResult(i, 12);
        }else{
            Toast.makeText(this,"Not Supported",Toast.LENGTH_SHORT).show();}
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 10:
                if(resultCode == RESULT_OK && data != null){
                    ArrayList<String>result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    editName.setText(result.get(0)+"\n"+"Your Name  :"+a+"\n"+"And your age is :"+b);
                }

                break;
            case 11:
                if(resultCode == RESULT_OK && data != null){
                    ArrayList<String>result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    editSurname.setText(result.get(0));
                }
                break;
            case 12:
                if(resultCode == RESULT_OK && data != null){
                    ArrayList<String>result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    editMarks.setText(result.get(0));
                }
                break;

        }
    }


    public void AddData(){
        btnAddData.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                boolean isInserted=myDb.insertData(editName.getText().toString(),editSurname.getText().toString(),editMarks.getText().toString());
                if(isInserted==true)
                    Toast.makeText(exp.this, "Data Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(exp.this, "Data Not Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void viewAll(){
        btnviewAll.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Cursor res=myDb.getAllData();
                if(res.getCount()==0){
                    //show message
                    showMessage("Error", "No Data Found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID:"+res.getString(0)+"\n");
                    buffer.append("Your Symptoms:"+res.getString(1)+"\n");
                    buffer.append("Your Disease:"+res.getString(2)+"\n");
                    buffer.append("Medicines Prescribed:"+res.getString(3)+"\n\n");

                }
                //show All Data
                showMessage("Data",buffer.toString());
            }
        });
    }
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title+"Your Name  :"+a+"\n"+"And your age is :"+b);
        builder.setMessage(Message);
        builder.show();
    }
    public void DeleteData(){
        btndelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Integer deletedRows=myDb.deleteData(editId.getText().toString());
                if(deletedRows>0)
                    Toast.makeText(exp.this, "Data Deleted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(exp.this, "Data Not Deleted", Toast.LENGTH_LONG).show();
            }
        });
    }
    public void UpdateData(){
        btnUpdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                boolean isUpdate=myDb.updateData(editId.getText().toString(),editName.getText().toString(), editSurname.getText().toString(),editMarks.getText().toString());
                if(isUpdate==true){
                    Toast.makeText(exp.this, "Data Updated", Toast.LENGTH_LONG).show();
                }
                else
                    Toast.makeText(exp.this, "Data Not Updated", Toast.LENGTH_LONG).show();
            }
        });
        btnout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(exp.this,pres.class);
                startActivity(i);
            }
        });
        btnmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(exp.this,mail.class);
                c=editName.getText().toString();
                d=editSurname.getText().toString();
                e=editMarks.getText().toString();
                i.putExtra("e1",c);
                i.putExtra("e2", d);
                i.putExtra("e3", e);
                i.putExtra("value",a);
                i.putExtra("age", b);
                startActivity(i);
            }
        });
    }




}

