package com.javahelps.onlinedoctor;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class dashboard_p extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    ActionBar actionBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_p);

        actionBar = getSupportActionBar();
        actionBar.setTitle("Profile");

        firebaseAuth=FirebaseAuth.getInstance();
        BottomNavigationView navigationView=findViewById(R.id.navigation);
        navigationView.setOnNavigationItemSelectedListener(selectedListener);

        actionBar.setTitle("Profile");
        ProfileFragment fragment11=new ProfileFragment();
        FragmentTransaction ft11=getSupportFragmentManager().beginTransaction();
        ft11.replace(R.id.content_p,fragment11,"");
        ft11.commit();

    }
    private BottomNavigationView.OnNavigationItemSelectedListener selectedListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()){
                        case R.id.nav_profile_p:
                            actionBar.setTitle("Profile");
                            ProfileFragment fragment11=new ProfileFragment();
                            FragmentTransaction ft11=getSupportFragmentManager().beginTransaction();
                            ft11.replace(R.id.content_p,fragment11,"");
                            ft11.commit();
                            return true;
                       case R.id.nav_users:
                            actionBar.setTitle("Doctors");
                            UsersFragment fragment2=new UsersFragment();
                            FragmentTransaction ft2=getSupportFragmentManager().beginTransaction();
                            ft2.replace(R.id.content_p,fragment2,"");
                            ft2.commit();
                            return true;

                        case R.id.nav_chat_p:
                            actionBar.setTitle("Chat");
                            ChatFragment fragment3=new ChatFragment();
                            FragmentTransaction ft3=getSupportFragmentManager().beginTransaction();
                            ft3.replace(R.id.content_p,fragment3,"");
                            ft3.commit();
                            return true;
                    }
                    return false;
                }
            };
    private void checkUserStatus_p(){
        FirebaseUser user=firebaseAuth.getCurrentUser();
        if(user!=null){
//mm.setText(user.getEmail());
        }
        else{
            startActivity(new Intent(dashboard_p.this,Conas.class));
            finish();
        }
    }
    protected void onStart() {
        checkUserStatus_p();
        super.onStart();
    }
}
