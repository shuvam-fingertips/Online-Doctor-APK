package com.javahelps.onlinedoctor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class pres_2 extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText editName,editSurname,editMarks,editId;
    TextView et5,tv1;
    Button btnAddData,btnviewAll,btndelete,btnUpdate,btnout,btnmail;
    String a,b,c,d,e;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pres2);
        myDb=new DatabaseHelper(this);
        a=getIntent().getStringExtra("value");
        b=getIntent().getStringExtra("age");

        editName=findViewById(R.id.editText_name);
        tv1=findViewById(R.id.tv1);
        editSurname=findViewById(R.id.editText_surname);
        editMarks=findViewById(R.id.editText_Marks);
        btnAddData=(Button) findViewById(R.id.button_add);
        btnviewAll=(Button) findViewById(R.id.button_viewAll);
        btnUpdate=(Button) findViewById(R.id.button_update);
        btndelete=(Button) findViewById(R.id.button_delete);
        btnout=findViewById(R.id.button_out);
        btnmail=findViewById(R.id.btnmail);
        editId=findViewById(R.id.editTextId);
        editName.setText("\n"+"Your Name  :"+a+"\n"+" And your age is :"+b);
        AddData();
        viewAll();
        UpdateData();
        DeleteData();
    }

    public void AddData(){
        btnAddData.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                boolean isInserted=myDb.insertData(editName.getText().toString(),editSurname.getText().toString(),editMarks.getText().toString());
                if(isInserted==true)
                    Toast.makeText(pres_2.this, "Data Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(pres_2.this, "Data Not Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void viewAll(){
        btnviewAll.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Cursor res=myDb.getAllData();
                if(res.getCount()==0){
                    //show message
                    showMessage("Error", "No Data Found");
                    return;
                }

                StringBuffer buffer=new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID:"+res.getString(0)+"\n");
                    buffer.append(" YOUR SYMPTOMS:"+res.getString(1)+"\n");
                    buffer.append("YOUR DISEASE IS:"+res.getString(2)+"\n");
                    buffer.append("MEDICINES PRESCRIBED ARE"+res.getString(3)+"\n\n");

                }
                //show All Data
                showMessage("Data",buffer.toString());
            }
        });
    }
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title+"Your Name  :"+a+"\n"+" And your age is :"+b);
        builder.setMessage(Message);
        builder.show();
    }
    public void DeleteData(){
        btndelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Integer deletedRows=myDb.deleteData(editId.getText().toString());
                if(deletedRows>0)
                    Toast.makeText(pres_2.this, "Data Deleted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(pres_2.this, "Data Not Deleted", Toast.LENGTH_LONG).show();
            }
        });
    }
    public void UpdateData(){
        btnUpdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                boolean isUpdate=myDb.updateData(editId.getText().toString(),editName.getText().toString(), editSurname.getText().toString(),editMarks.getText().toString());
                if(isUpdate==true){
                    Toast.makeText(pres_2.this, "Data Updated", Toast.LENGTH_LONG).show();
                }
                else
                    Toast.makeText(pres_2.this, "Data Not Updated", Toast.LENGTH_LONG).show();
            }
        });
        btnout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(pres_2.this,pres.class);
                startActivity(i);
            }
        });
        btnmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(pres_2.this,mail.class);
                c=editName.getText().toString();
                d=editSurname.getText().toString();
                e=editMarks.getText().toString();
                i.putExtra("e1",c);
                i.putExtra("e2", d);
                i.putExtra("e3", e);
                i.putExtra("value",a);
                i.putExtra("age", b);
                startActivity(i);
            }
        });

    }

}